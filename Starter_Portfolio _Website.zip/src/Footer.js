import React from 'react';
function Footer() {
    return (
        <footer>
            <p class="ab">© 2023  SAIT  RM:NK201 Continuing Education Class</p>
        </footer>
    );
}

export default Footer;

