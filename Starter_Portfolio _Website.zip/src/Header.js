import React from 'react';

const Header = ()=> {
    return (
    <header>
        <div>
        <h1>Shiju Puthiyoth</h1>  
    
        <h3>Results-driven professional with a strong background in customer service and IT acumen, seeking a challenging position where I can leverage my expertise and customer-centric approach to contribute organizational success.</h3>
        
        </div>
      <nav>
      <ul>   
        <b></b><td><li><a href="/About.js/paragraph1">Key Summary</a></li></td><b></b>
        <b></b><td><li><a href="/About.js/paragraph2">Skills</a></li></td><b></b>
        <b></b><td><li><a href="/About.js/paragraph3">Interest and Activities</a></li></td><b></b>
        <b></b><td><li><a href="./About.js/paragraph4">Technical Skills</a></li></td><b></b> 
      </ul>
      </nav>
    </header>
      );
}

export default Header;

